import RPi.GPIO as GPIO
import time

pin = 17

def print_message():
    print("----program running----")

def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin, GPIO.OUT, initial=GPIO.HIGH)

def main():
    print_message()
    while True:
        print("buzzer on")
        GPIO.output(pin, GPIO.LOW)
        time.sleep(0.2)
        print("buzzer off")
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(0.2)
        

def destroy():
    GPIO.output(pin, GPIO.HIGH)
    GPIO.cleanup()


if __name__ == "__main__":
    setup()
    try:
        main()
    
    except KeyboardInterrupt:
        destroy()


